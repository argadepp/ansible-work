import boto3
import os

# Initialize the SSM, EC2, and SNS clients
ssm_client = boto3.client('ssm')
ec2_client = boto3.client('ec2')
sns_client = boto3.client('sns')

# Fetch the latest Bottlerocket AMI details
def get_bottlerocket_ami_details(eks_version, architecture):
    parameter_name = f"/aws/service/bottlerocket/aws-k8s-{eks_version}/{architecture}/latest/image_id"
    ami_version_name = f"/aws/service/bottlerocket/aws-k8s-{eks_version}/{architecture}/latest/image_version"
    
    ami_id = ssm_client.get_parameter(Name=parameter_name)['Parameter']['Value']
    ami_version = ssm_client.get_parameter(Name=ami_version_name)['Parameter']['Value']

    ami_details = ec2_client.describe_images(ImageIds=[ami_id])
    image = ami_details['Images'][0]
    creation_date = image.get('CreationDate', 'N/A')
    deprecation_time = image.get('DeprecationTime', 'N/A')

    return {
        'AMI_ID': ami_id,
        'AMI_VERSION': ami_version,
        'Creation Date': creation_date,
        'Deprecation Time': deprecation_time
    }

# Fetch the current running instance AMI details based on tag
def get_instance_ami_details():
    filters = [{
        'Name': 'tag:eks:cluster-name',
        'Values': ['eks']
    }]
    
    instances = ec2_client.describe_instances(Filters=filters)
    
    # Assuming there is only one instance to fetch details for
    if len(instances['Reservations']) > 0:
        instance = instances['Reservations'][0]['Instances'][0]
        ami_id = instance.get('ImageId', 'N/A')
        
        ami_details = ec2_client.describe_images(ImageIds=[ami_id])
        image = ami_details['Images'][0]
        creation_date = image.get('CreationDate', 'N/A')
        deprecation_time = image.get('DeprecationTime', 'N/A')
        
        return {
            'Instance AMI_ID': ami_id,
            'Creation Date': creation_date,
            'Deprecation Time': deprecation_time
        }
    return None

# Send SNS Notification
def send_sns_notification(bottlerocket_details, instance_details):
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']  # SNS topic ARN from environment variables
    
    # Construct the message
    message = (
        f"Hi Team,\n\n"
        f"Please find below details regarding Bottlerocket AMI and the instance AMI.\n\n"
        f"Bottlerocket AMI Details:\n"
        f"AMI ID: {bottlerocket_details['AMI_ID']}\n"
        f"AMI Version: {bottlerocket_details['AMI_VERSION']}\n"
        f"Creation Date: {bottlerocket_details['Creation Date']}\n"
        f"Deprecation Time: {bottlerocket_details['Deprecation Time']}\n\n"
        f"Instance AMI Details:\n"
        f"AMI ID: {instance_details['Instance AMI_ID']}\n"
        f"Creation Date: {instance_details['Creation Date']}\n"
        f"Deprecation Time: {instance_details['Deprecation Time']}\n"
    )
    
    # Publish message to SNS
    response = sns_client.publish(
        TopicArn=sns_topic_arn,
        Subject="Bottlerocket and Instance AMI Details",
        Message=message
    )
    return response

def lambda_handler(event, context):
    # Fetch Bottlerocket AMI and instance AMI details
    bottlerocket_details = get_bottlerocket_ami_details('1.29', 'x86_64')
    instance_details = get_instance_ami_details()

    if instance_details is not None:
        sns_response = send_sns_notification(bottlerocket_details, instance_details)
        return {
            'statusCode': 200,
            'body': sns_response
        }
    else:
        return {
            'statusCode': 404,
            'body': "No instances found with the specified tag."
        }